import SupportPanel from '../components/Support/SupportPanel';

export default function SupportPage() {
  return <SupportPanel />;
}
