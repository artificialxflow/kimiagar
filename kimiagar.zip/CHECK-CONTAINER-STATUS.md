# بررسی وضعیت Container و رفع 502

## ✅ وضعیت فعلی (از دستورات)

- ✅ Node.js process در حال اجرا است (PID 19)
- ✅ Health check کار می‌کند
- ✅ دیتابیس متصل است
- ✅ Migration‌ها اعمال شده‌اند

## 🔍 بررسی‌های لازم

### 1. بررسی اینکه آیا Container Restart می‌شود

از terminal در پنل Runflare:

```bash
# بررسی PID - اگر تغییر کرد یعنی restart شده
ps aux | grep node

# بررسی uptime
ps -p 19 -o etime

# بررسی لاگ‌های restart
# (از پنل Runflare → مشاهده لاگ)
```

**اگر PID تغییر کرد یا uptime کم است** → یعنی container restart می‌شود

---

### 2. بررسی Probe‌ها

در پنل Runflare:
1. به بخش **"تست سلامت"** برو
2. **Startup Probe** را بررسی کن:
   - پورت باید **3001** باشد (نه 3000)
3. **Liveness Probe** را بررسی کن:
   - پورت باید **3001** باشد (نه 3000)

**اگر هنوز 3000 است** → تغییر بده به 3001

---

### 3. بررسی Nginx Configuration

مشکل 502 معمولاً از این است که:
- Nginx به پورت 3000 اشاره می‌کند (اشتباه)
- یا به پورت 3001 اشاره می‌کند اما container restart می‌شود

**راه‌حل:**
1. Probe‌ها را به 3001 تغییر بده
2. چند دقیقه صبر کن
3. صفحه را refresh کن

---

### 4. تست مستقیم از داخل Container

از terminal:

```bash
# تست health check
curl http://localhost:3001/api/health

# تست register (برای بررسی لاگ‌ها)
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser999",
    "password": "Test1234",
    "confirmPassword": "Test1234",
    "firstName": "تست",
    "lastName": "کاربر",
    "phoneNumber": "09123456794",
    "nationalId": "1234567895"
  }'
```

---

## 🎯 اقدامات فوری

### گام 1: تغییر Probe‌ها (اگر هنوز نکردی)

در پنل Runflare → تست سلامت:
- Startup Probe: پورت **3001**
- Liveness Probe: پورت **3001**

### گام 2: صبر کردن

2-3 دقیقه صبر کن تا تغییرات اعمال شود.

### گام 3: تست از مرورگر

به `radizgold.ir` برو و ببین آیا 502 رفع شده یا نه.

---

## 🔧 اگر هنوز 502 می‌بینی

### بررسی 1: Container Restart

از پنل Runflare → مشاهده لاگ:
- دنبال `SIGTERM` بگرد
- دنبال `Startup probe failed` بگرد
- اگر این پیام‌ها را دیدی → Probe‌ها را تغییر بده

### بررسی 2: Nginx Upstream

اگر دسترسی به تنظیمات Nginx داری:
- مطمئن شو که upstream به `localhost:3001` اشاره می‌کند

### بررسی 3: Domain Configuration

در پنل Runflare:
- بررسی کن که domain به درستی تنظیم شده است
- بررسی کن که SSL certificate معتبر است

---

## 📋 چک‌لیست نهایی

- [ ] Probe‌ها روی پورت 3001 هستند
- [ ] Environment Variable `PORT=3001` تنظیم شده است
- [ ] 2-3 دقیقه صبر کردم
- [ ] از مرورگر تست کردم (نه فقط از terminal)
- [ ] اگر هنوز 502 می‌بینی، لاگ‌های restart را بررسی کردم

