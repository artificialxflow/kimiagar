"use client";

import React from 'react';
import Link from 'next/link';
import { ShoppingCart, TrendingUp, ArrowUpRight, Send } from 'lucide-react';

const QuickActions: React.FC = () => {
  const actions = [
    {
      title: 'خرید طلا',
      description: 'خرید طلا و سکه',
      icon: ShoppingCart,
      link: '/buy',
      color: 'bg-gradient-to-br from-green-500 to-green-600',
      hoverColor: 'hover:from-green-600 hover:to-green-700',
      iconColor: 'text-green-50'
    },
    {
      title: 'فروش طلا',
      description: 'فروش طلا و سکه',
      icon: TrendingUp,
      link: '/sell',
      color: 'bg-gradient-to-br from-red-500 to-red-600',
      hoverColor: 'hover:from-red-600 hover:to-red-700',
      iconColor: 'text-red-50'
    },
    {
      title: 'شارژ کیف پول',
      description: 'شارژ کیف پول ریالی',
      icon: ArrowUpRight,
      link: '/wallet?tab=charge',
      color: 'bg-gradient-to-br from-purple-500 to-purple-600',
      hoverColor: 'hover:from-purple-600 hover:to-purple-700',
      iconColor: 'text-purple-50'
    },
    {
      title: 'انتقال طلا',
      description: 'انتقال طلا به کاربر دیگر',
      icon: Send,
      link: '/transfer',
      color: 'bg-gradient-to-br from-gold-500 to-gold-600',
      hoverColor: 'hover:from-gold-600 hover:to-gold-700',
      iconColor: 'text-gold-50'
    },
    {
      title: 'سایر موارد',
      description: 'تحویل فیزیکی و سایر خدمات',
      icon: ArrowUpRight,
      link: '/settings',
      color: 'bg-gradient-to-br from-gray-500 to-gray-600',
      hoverColor: 'hover:from-gray-600 hover:to-gray-700',
      iconColor: 'text-gray-50'
    }
  ];

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-border-100 p-6 hover:shadow-xl transition-all duration-300">
      <h2 className="text-xl font-semibold text-text-800 mb-6 flex items-center">
        <div className="w-2 h-8 bg-gradient-to-b from-gold-400 to-gold-600 rounded-full ml-3"></div>
        دسترسی سریع
      </h2>
      
      {/* Horizontal Layout for all sizes */}
      <div className="flex space-x-4 space-x-reverse overflow-x-auto pb-2">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <Link
              key={index}
              href={action.link}
              className="flex-shrink-0 w-28 lg:w-32 flex flex-col items-center space-y-3 p-4 rounded-xl hover:bg-background-50 transition-all duration-300 group border border-transparent hover:border-border-200"
            >
              <div className={`w-12 h-12 lg:w-14 lg:h-14 rounded-xl flex items-center justify-center ${action.color} ${action.hoverColor} transition-all duration-300 shadow-md group-hover:shadow-lg transform group-hover:scale-105`}>
                <Icon className={`w-6 h-6 ${action.iconColor}`} />
              </div>
              <div className="text-center">
                <div className="text-xs lg:text-sm font-medium text-text-800 group-hover:text-gold-600 transition-colors duration-300 leading-tight">
                  {action.title}
                </div>
                <div className="text-xs text-text-500 mt-1 hidden lg:block">
                  {action.description}
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default QuickActions;