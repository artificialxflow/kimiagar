# راهنمای رفع مشکل Register و مشاهده لاگ‌ها

## 🔴 مشکلات شناسایی شده

### 1. مشکل پورت Probe‌ها
- **Startup Probe**: روی پورت **3000** تنظیم شده ❌
- **Liveness Probe**: روی پورت **3000** تنظیم شده ❌
- **سرور واقعی**: روی پورت **3001** اجرا می‌شود ✅

**نتیجه:** Probe‌ها fail می‌شوند و container restart می‌شود!

### 2. مشکل RAM
- **مصرف RAM پروژه**: 99% (1 GB / 2 GB) ⚠️
- این می‌تواند باعث SIGTERM و restart شود

### 3. مشکل Register
- خطای 500 در `/api/auth/register`
- نیاز به بررسی لاگ‌های دقیق

---

## ✅ راه‌حل‌ها

### گام 1: تغییر پورت Probe‌ها به 3001

در پنل Runflare:

1. به بخش **"تست سلامت"** (Health Test) برو
2. **Startup Probe** را ویرایش کن:
   - **پورت**: `3000` → `3001` تغییر بده
   - **نوع**: `tcpSocket` (می‌تواند همان بماند)
   - **دوره**: `10s`
   - **زمان صبر**: `2s`
   - **تاخیر شروع**: `10s` (افزایش بده)
   - **failureThreshold**: `10` (افزایش بده)

3. **Liveness Probe** را ویرایش کن:
   - **پورت**: `3000` → `3001` تغییر بده
   - **نوع**: `tcpSocket` (می‌تواند همان بماند)
   - **دوره**: `10s`
   - **زمان صبر**: `2s`
   - **تاخیر شروع**: `10s`
   - **failureThreshold**: `3`

**یا بهتر است از HTTP Probe استفاده کنی:**

برای **Startup Probe**:
- **نوع**: `httpGet` (به جای `tcpSocket`)
- **روت**: `/health` یا `/api/health`
- **پورت**: `3001`

برای **Liveness Probe**:
- **نوع**: `httpGet`
- **روت**: `/health` یا `/api/health`
- **پورت**: `3001`

---

### گام 2: بررسی Environment Variables

در پنل Runflare، به بخش **"تنظیم متغیر محیطی"** برو و مطمئن شو:

```env
PORT=3001
HOST=0.0.0.0
NODE_ENV=production
DATABASE_URL=postgresql://...
JWT_SECRET=...
JWT_REFRESH_SECRET=...
```

---

### گام 3: مشاهده لاگ‌های Register

#### روش 1: از پنل Runflare (توصیه می‌شود)

1. در پنل Runflare، روی آیکون **"مشاهده لاگ"** (View Logs) کلیک کن
2. در فیلتر لاگ‌ها، دنبال این متن‌ها بگرد:
   - `📝 [Register]`
   - `❌ [Register]`
   - `✅ [Register]`
3. یا از فیلتر زمانی استفاده کن (مثلاً "15 دقیقه اخیر")

#### روش 2: از Terminal در پنل Runflare

1. در پنل Runflare، روی آیکون **"ترمینال"** (Terminal) کلیک کن
2. این دستورات را اجرا کن:

```bash
# مشاهده لاگ‌های اخیر
tail -n 100 /var/log/app.log

# یا اگر لاگ‌ها در stdout هستند
# (در Runflare معمولاً لاگ‌ها در console نمایش داده می‌شوند)
```

#### روش 3: از داخل Container (اگر دسترسی داری)

```bash
# مشاهده لاگ‌های process
ps aux | grep node

# مشاهده لاگ‌های npm
cat /root/.npm/_logs/*.log | tail -n 50
```

---

### گام 4: تست Register و مشاهده لاگ‌ها

1. **اول probe‌ها را تغییر بده** (گام 1)
2. **سپس یک درخواست register بفرست:**

```bash
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser999",
    "password": "Test1234",
    "confirmPassword": "Test1234",
    "firstName": "تست",
    "lastName": "کاربر",
    "phoneNumber": "09123456793",
    "nationalId": "1234567894"
  }'
```

3. **بلافاصله به پنل Runflare برو و لاگ‌ها را ببین**

لاگ‌هایی که باید ببینی:
```
📝 [Register] ========== شروع ثبت‌نام ==========
📝 [Register] درخواست ثبت‌نام دریافت شد
📝 [Register] در حال خواندن body...
📝 [Register] Body خوانده شد
📝 [Register] در حال ایجاد کاربر جدید در دیتابیس...
📝 [Register] Step 1: ایجاد کاربر...
✅ [Register] کاربر ایجاد شد با ID: ...
📝 [Register] Step 2: ایجاد کیف پول‌های پیش‌فرض...
✅ [Register] کیف پول‌ها ایجاد شدند: 2
📝 [Register] Step 3: ایجاد تنظیمات کاربر...
✅ [Register] تنظیمات کاربر ایجاد شد
📝 [Register] در حال ایجاد JWT tokens...
✅ [Register] ========== ثبت‌نام موفق ==========
```

**یا اگر خطا رخ دهد:**
```
❌ [Register] ========== خطا در ثبت‌نام ==========
❌ [Register] خطا در ثبت‌نام: ...
📋 [Register] نوع خطا: ...
📋 [Register] پیام خطا: ...
📋 [Register] کد خطا: ...
📋 [Register] Prisma Meta: ...
```

---

## ⚠️ مشکل RAM

مصرف RAM پروژه **99%** است. این می‌تواند باعث:
- SIGTERM signals
- Container restarts
- Timeout در transaction‌ها

### راه‌حل‌های موقت:
1. **افزایش RAM** (اگر امکان دارد)
2. **کاهش تعداد سرویس‌های دیگر** در پروژه
3. **بهینه‌سازی کد** (کاهش memory leaks)

---

## 📋 چک‌لیست

- [ ] Startup Probe پورت را به 3001 تغییر دادم
- [ ] Liveness Probe پورت را به 3001 تغییر دادم
- [ ] Environment Variable `PORT=3001` تنظیم شده است
- [ ] یک درخواست register فرستادم
- [ ] لاگ‌های register را از پنل Runflare بررسی کردم
- [ ] لاگ‌های خطا را کپی کردم و برای بررسی فرستادم

---

## 🔍 اگر هنوز مشکل داری

1. **لاگ‌های کامل register را کپی کن** (از پنل Runflare)
2. **خروجی این دستورات را بفرست:**

```bash
# بررسی پورت
netstat -tlnp | grep 3001

# بررسی environment variables
echo $PORT
echo $HOST

# بررسی process
ps aux | grep node
```

3. **سپس لاگ‌ها و خروجی‌ها را برایم بفرست** تا بتوانم مشکل را دقیق‌تر شناسایی کنم.

