# راهنمای رفع خطای 502 Bad Gateway

## 🔴 مشکل

خطای **502 Bad Gateway** یعنی:
- Nginx (reverse proxy) نمی‌تواند به سرور backend (Node.js) متصل شود
- یا سرور backend در حال restart است

## 🔍 علت‌های احتمالی

### 1. Container در حال Restart است
از لاگ‌ها مشخص است که سرور دو بار start شده:
```
> node server.js
🚀 Starting server...
✅ Server ready on http://0.0.0.0:3001
📊 Process ID: 19
```

این یعنی container restart می‌شود و Nginx نمی‌تواند به آن متصل شود.

### 2. Probe‌ها هنوز روی پورت 3000 هستند
اگر probe‌ها هنوز روی 3000 باشند، container restart می‌شود.

### 3. مشکل RAM
مصرف RAM 99% می‌تواند باعث restart شود.

---

## ✅ راه‌حل‌ها

### گام 1: بررسی و تغییر Probe‌ها (اولویت اول)

1. **به پنل Runflare برو**
2. **به بخش "تست سلامت" (Health Test) برو**
3. **Startup Probe را بررسی کن:**
   - اگر پورت **3000** است → به **3001** تغییر بده
   - **تاخیر شروع** را به **30s** افزایش بده
   - **failureThreshold** را به **10** افزایش بده

4. **Liveness Probe را بررسی کن:**
   - اگر پورت **3000** است → به **3001** تغییر بده
   - **تاخیر شروع** را به **10s** افزایش بده

5. **ذخیره کن و منتظر بمان** (2-3 دقیقه)

---

### گام 2: بررسی Environment Variables

در پنل Runflare، به بخش **"تنظیم متغیر محیطی"** برو و مطمئن شو:

```env
PORT=3001
HOST=0.0.0.0
NODE_ENV=production
```

---

### گام 3: بررسی وضعیت Container

در پنل Runflare:

1. **به بخش "مشاهده لاگ" (View Logs) برو**
2. **دنبال این پیام‌ها بگرد:**
   - `SIGTERM received` → یعنی container kill شده
   - `Startup probe failed` → یعنی probe fail شده
   - `Unhealthy` → یعنی health check fail شده

3. **اگر container در حال restart است:**
   - Probe‌ها را تغییر بده (گام 1)
   - چند دقیقه صبر کن
   - دوباره بررسی کن

---

### گام 4: تست Health Check

بعد از تغییر probe‌ها، این دستورات را از terminal اجرا کن:

```bash
# تست health check
curl http://localhost:3001/api/health

# باید این خروجی را ببینی:
# {"status":"ok","timestamp":"...","environment":"production",...}
```

اگر health check کار کرد، یعنی سرور در حال اجرا است.

---

### گام 5: بررسی Nginx Configuration

اگر بعد از تغییر probe‌ها هنوز 502 می‌بینی:

1. **در پنل Runflare، به بخش تنظیمات Nginx برو**
2. **مطمئن شو که upstream به پورت 3001 اشاره می‌کند:**
   ```nginx
   upstream backend {
       server localhost:3001;
   }
   ```

3. **یا اگر از domain استفاده می‌کنی:**
   - مطمئن شو که domain به درستی تنظیم شده است

---

## 🔧 دستورات مفید برای Debug

از terminal در پنل Runflare:

```bash
# 1. بررسی اینکه سرور روی 3001 در حال اجرا است
netstat -tlnp | grep 3001

# باید ببینی:
# tcp  0  0  0.0.0.0:3001  0.0.0.0:*  LISTEN  <PID>/node

# 2. بررسی process
ps aux | grep node

# 3. بررسی environment variables
echo $PORT
echo $HOST

# 4. تست health check
curl http://localhost:3001/api/health

# 5. بررسی لاگ‌های اخیر
tail -n 50 /var/log/app.log
```

---

## 📋 چک‌لیست

- [ ] Startup Probe پورت را به 3001 تغییر دادم
- [ ] Liveness Probe پورت را به 3001 تغییر دادم
- [ ] تاخیر شروع Startup Probe را به 30s افزایش دادم
- [ ] Environment Variable `PORT=3001` تنظیم شده است
- [ ] 2-3 دقیقه صبر کردم تا تغییرات اعمال شود
- [ ] Health check را تست کردم (`curl http://localhost:3001/api/health`)
- [ ] اگر هنوز 502 می‌بینی، لاگ‌ها را بررسی کردم

---

## ⚠️ اگر هنوز مشکل داری

1. **لاگ‌های کامل را کپی کن** (از پنل Runflare → مشاهده لاگ)
2. **خروجی این دستورات را بفرست:**
   ```bash
   netstat -tlnp | grep 3001
   ps aux | grep node
   curl http://localhost:3001/api/health
   ```
3. **وضعیت probe‌ها را بگو** (پورت‌ها روی 3000 هستند یا 3001؟)

---

## 💡 نکته مهم

**502 Bad Gateway** معمولاً به این معنی است که:
- سرور backend در حال restart است (به خاطر probe‌های اشتباه)
- یا Nginx نمی‌تواند به backend متصل شود

**راه‌حل اصلی:** تغییر probe‌ها از 3000 به 3001

