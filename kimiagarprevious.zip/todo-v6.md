# TODO v6 - پنل ادمین کامل برای مدیریت کاربران و تراکنش‌ها

## 📋 خلاصه تغییرات

این TODO شامل تمام کارهای لازم برای پیاده‌سازی پنل ادمین کامل است که به ادمین امکان می‌دهد:
- مشاهده و مدیریت درخواست‌های خرید (✅ موجود)
- تایید/رد درخواست‌های خرید (✅ موجود)
- **شارژ دستی موجودی کاربران** (❌ نیاز به پیاده‌سازی)
- **مشاهده موجودی کاربران** (❌ نیاز به پیاده‌سازی)
- **ثبت و مدیریت فیش‌های واریزی** (❌ نیاز به پیاده‌سازی)

**نکته مهم:** تمام این قابلیت‌ها با استفاده از فیلدهای موجود دیتابیس پیاده‌سازی می‌شوند و نیازی به تغییر Schema نیست.

---

## 🔧 Backend APIs

### 1. API مشاهده موجودی کاربران
- [ ] ایجاد `app/api/admin/users/[userId]/wallet/route.ts`
  - [ ] GET endpoint برای دریافت موجودی کاربر
  - [ ] دریافت کیف پول‌های ریالی و طلایی
  - [ ] دریافت آخرین تراکنش‌ها (اختیاری)
  - [ ] بررسی دسترسی ادمین (isAdmin check)
  - [ ] Error handling کامل
  - [ ] Logging برای دیباگ

### 2. API شارژ دستی موجودی
- [ ] ایجاد `app/api/admin/wallet/charge/route.ts`
  - [ ] POST endpoint برای شارژ موجودی
  - [ ] دریافت پارامترها: `userId`, `amount`, `walletType` ('RIAL' | 'GOLD'), `description`, `receiptNumber` (اختیاری)
  - [ ] بررسی دسترسی ادمین (isAdmin check)
  - [ ] Validation ورودی‌ها (مبلغ مثبت، نوع کیف پول معتبر)
  - [ ] بررسی وجود کاربر
  - [ ] بررسی وجود کیف پول
  - [ ] استفاده از Prisma Transaction برای atomicity
  - [ ] به‌روزرسانی موجودی کیف پول
  - [ ] ثبت تراکنش با:
    - [ ] `type: 'DEPOSIT'`
    - [ ] `status: 'COMPLETED'`
    - [ ] `referenceId: receiptNumber` (اگر ارائه شده)
    - [ ] `metadata: { adminId, receiptNumber, receiptDate, adminNotes }`
  - [ ] ایجاد Notification برای کاربر
  - [ ] ثبت Audit Log (اختیاری)
  - [ ] Error handling کامل
  - [ ] Logging برای دیباگ

### 3. API لیست تراکنش‌های کاربر
- [ ] ایجاد `app/api/admin/users/[userId]/transactions/route.ts`
  - [ ] GET endpoint برای دریافت تراکنش‌های کاربر
  - [ ] پشتیبانی از pagination (page, limit)
  - [ ] فیلتر بر اساس نوع تراکنش (اختیاری)
  - [ ] فیلتر بر اساس وضعیت (اختیاری)
  - [ ] مرتب‌سازی بر اساس تاریخ (جدیدترین اول)
  - [ ] بررسی دسترسی ادمین
  - [ ] Error handling

### 4. بهبود API موجود کاربران
- [ ] بهبود `app/api/admin/users/route.ts`
  - [ ] اضافه کردن موجودی کیف پول‌ها به response (در select)
  - [ ] اضافه کردن تعداد تراکنش‌ها (در _count)
  - [ ] اضافه کردن فیلتر بر اساس موجودی (اختیاری)

### 5. API مشاهده جزئیات سفارش
- [ ] بررسی `app/api/admin/orders/route.ts`
  - [ ] اطمینان از نمایش تمام جزئیات لازم
  - [ ] اضافه کردن اطلاعات کیف پول کاربر (اگر نیاز است)
  - [ ] بهبود error messages

---

## 🎨 Frontend Components

### 1. کامپوننت مشاهده موجودی کاربر
- [ ] ایجاد `app/components/Admin/UserWallet.tsx`
  - [ ] نمایش موجودی ریالی
  - [ ] نمایش موجودی طلایی
  - [ ] نمایش موجودی سکه‌ها (اگر نیاز است)
  - [ ] نمایش آخرین تراکنش‌ها
  - [ ] دکمه "شارژ موجودی"
  - [ ] استایل مشابه کامپوننت‌های موجود
  - [ ] Loading state
  - [ ] Error state
  - [ ] RTL support

### 2. کامپوننت شارژ موجودی
- [ ] ایجاد `app/components/Admin/ChargeWalletModal.tsx`
  - [ ] Modal برای شارژ موجودی
  - [ ] فیلد انتخاب نوع کیف پول (RIAL/GOLD)
  - [ ] فیلد مبلغ (با validation)
  - [ ] فیلد شماره فیش (اختیاری)
  - [ ] فیلد توضیحات
  - [ ] نمایش موجودی فعلی کاربر
  - [ ] دکمه‌های "تایید" و "انصراف"
  - [ ] Loading state هنگام ارسال
  - [ ] Success/Error messages
  - [ ] استایل مشابه Modal‌های موجود
  - [ ] RTL support

### 3. کامپوننت لیست تراکنش‌های کاربر
- [ ] ایجاد `app/components/Admin/UserTransactions.tsx`
  - [ ] جدول تراکنش‌ها
  - [ ] Pagination
  - [ ] فیلتر بر اساس نوع تراکنش
  - [ ] فیلتر بر اساس وضعیت
  - [ ] نمایش شماره فیش (اگر وجود دارد)
  - [ ] نمایش تاریخ و زمان
  - [ ] استایل مشابه جداول موجود
  - [ ] Loading state
  - [ ] Empty state

### 4. بهبود صفحه پنل ادمین
- [ ] بهبود `app/admin/page.tsx`
  - [ ] اضافه کردن تب "کیف پول‌ها" (اختیاری)
  - [ ] بهبود تب "کاربران":
    - [ ] اضافه کردن ستون "موجودی ریالی"
    - [ ] اضافه کردن ستون "موجودی طلایی"
    - [ ] اضافه کردن دکمه "مشاهده جزئیات" برای هر کاربر
    - [ ] اضافه کردن دکمه "شارژ موجودی" برای هر کاربر
  - [ ] بهبود تب "سفارش‌ها":
    - [ ] اضافه کردن فیلتر بر اساس وضعیت
    - [ ] اضافه کردن جستجو بر اساس نام کاربر
    - [ ] بهبود نمایش جزئیات سفارش
  - [ ] اضافه کردن Modal برای مشاهده جزئیات کاربر
  - [ ] بهبود Error handling
  - [ ] بهبود Loading states

### 5. کامپوننت جزئیات کاربر
- [ ] ایجاد `app/components/Admin/UserDetailsModal.tsx`
  - [ ] نمایش اطلاعات کامل کاربر
  - [ ] نمایش موجودی کیف پول‌ها
  - [ ] نمایش آخرین تراکنش‌ها
  - [ ] نمایش آخرین سفارش‌ها
  - [ ] دکمه "شارژ موجودی"
  - [ ] دکمه "تغییر وضعیت"
  - [ ] استایل مشابه Modal‌های موجود

---

## 🔐 Security & Validation

### 1. بررسی دسترسی ادمین
- [ ] اطمینان از بررسی `isAdmin` در تمام API های جدید
- [ ] استفاده از middleware برای محافظت از routes
- [ ] بررسی token در هر request
- [ ] Error handling مناسب برای دسترسی غیرمجاز

### 2. Validation ورودی‌ها
- [ ] Validation مبلغ (باید مثبت باشد)
- [ ] Validation نوع کیف پول (فقط RIAL یا GOLD)
- [ ] Validation userId (باید معتبر باشد)
- [ ] Validation receiptNumber (فرمت اختیاری)
- [ ] Validation description (حداکثر طول)
- [ ] پیام‌های خطای واضح و فارسی

### 3. Transaction Safety
- [ ] استفاده از Prisma Transaction برای عملیات شارژ
- [ ] بررسی موجودی قبل از کسر (برای برداشت)
- [ ] Rollback در صورت خطا
- [ ] بررسی race conditions

---

## 📊 UI/UX Improvements

### 1. بهبود تجربه کاربری
- [ ] اضافه کردن Tooltip برای توضیح قابلیت‌ها
- [ ] اضافه کردن Confirmation Dialog قبل از شارژ
- [ ] نمایش پیام موفقیت بعد از شارژ
- [ ] نمایش پیام خطا در صورت مشکل
- [ ] Auto-refresh لیست بعد از شارژ
- [ ] اضافه کردن Keyboard shortcuts (اختیاری)

### 2. Responsive Design
- [ ] اطمینان از Responsive بودن تمام کامپوننت‌های جدید
- [ ] تست در اندازه‌های مختلف صفحه
- [ ] بهبود نمایش در موبایل (اختیاری)

### 3. Accessibility
- [ ] اضافه کردن aria-label برای دکمه‌ها
- [ ] اضافه کردن aria-describedby برای فیلدها
- [ ] اطمینان از Keyboard navigation
- [ ] اطمینان از Contrast مناسب

---

## 🔄 Integration & State Management

### 1. State Management
- [ ] استفاده از useState برای state محلی
- [ ] استفاده از useEffect برای fetch data
- [ ] مدیریت Loading states
- [ ] مدیریت Error states
- [ ] به‌روزرسانی state بعد از عملیات موفق

### 2. API Integration
- [ ] استفاده از fetch با proper headers
- [ ] استفاده از Authorization header
- [ ] Error handling برای network errors
- [ ] Retry logic برای failed requests (اختیاری)
- [ ] Timeout handling

### 3. Real-time Updates (اختیاری)
- [ ] استفاده از WebSocket برای به‌روزرسانی لحظه‌ای (اختیاری)
- [ ] یا استفاده از polling برای به‌روزرسانی دوره‌ای

---

## 📝 Logging & Monitoring

### 1. Backend Logging
- [ ] اضافه کردن console.log برای شروع عملیات شارژ
- [ ] اضافه کردن console.error برای خطاها
- [ ] Logging اطلاعات مهم (userId, amount, adminId)
- [ ] Logging زمان انجام عملیات
- [ ] Logging نتیجه عملیات (موفق/ناموفق)

### 2. Frontend Logging
- [ ] Logging خطاهای API
- [ ] Logging عملیات کاربر (برای دیباگ)
- [ ] استفاده از console.error برای خطاها

### 3. Audit Trail (اختیاری)
- [ ] ثبت تمام عملیات شارژ در Audit Log
- [ ] ذخیره IP address
- [ ] ذخیره User Agent
- [ ] ذخیره timestamp

---

## 🧪 Testing & Quality Assurance

### 1. Manual Testing
- [ ] تست شارژ موجودی ریالی
- [ ] تست شارژ موجودی طلایی
- [ ] تست با مبالغ مختلف
- [ ] تست با کاربران مختلف
- [ ] تست Validation (مبلغ منفی، نوع نامعتبر)
- [ ] تست دسترسی (کاربر عادی نباید بتواند شارژ کند)
- [ ] تست مشاهده موجودی
- [ ] تست مشاهده تراکنش‌ها
- [ ] تست Pagination
- [ ] تست فیلترها

### 2. Error Scenarios
- [ ] تست با userId نامعتبر
- [ ] تست با کیف پول ناموجود
- [ ] تست با token نامعتبر
- [ ] تست با token منقضی شده
- [ ] تست با network error
- [ ] تست با server error

### 3. Edge Cases
- [ ] تست با مبلغ صفر
- [ ] تست با مبلغ خیلی بزرگ
- [ ] تست با کاراکترهای خاص در description
- [ ] تست با receiptNumber تکراری
- [ ] تست با کاربری که کیف پول ندارد

---

## 📚 Documentation

### 1. Code Documentation
- [ ] اضافه کردن JSDoc comments برای توابع
- [ ] اضافه کردن comments برای منطق پیچیده
- [ ] مستندسازی API endpoints
- [ ] مستندسازی کامپوننت‌ها

### 2. User Documentation (اختیاری)
- [ ] راهنمای استفاده از پنل ادمین
- [ ] راهنمای شارژ موجودی
- [ ] راهنمای مشاهده تراکنش‌ها

---

## 🚀 Deployment Checklist

### 1. Pre-deployment
- [ ] بررسی تمام TODO items
- [ ] تست کامل در محیط development
- [ ] بررسی console برای خطاها
- [ ] بررسی Network tab برای درخواست‌های ناموفق
- [ ] بررسی Performance

### 2. Deployment
- [ ] Build پروژه (`npm run build`)
- [ ] بررسی خطاهای build
- [ ] Deploy به سرور
- [ ] بررسی لاگ‌های سرور
- [ ] تست در محیط production

### 3. Post-deployment
- [ ] تست تمام قابلیت‌های جدید
- [ ] بررسی Performance در production
- [ ] بررسی Error rate
- [ ] جمع‌آوری feedback از کاربران

---

## 📋 خلاصه فایل‌های جدید

### Backend APIs
- [ ] `app/api/admin/users/[userId]/wallet/route.ts` - مشاهده موجودی کاربر
- [ ] `app/api/admin/wallet/charge/route.ts` - شارژ دستی موجودی
- [ ] `app/api/admin/users/[userId]/transactions/route.ts` - لیست تراکنش‌های کاربر

### Frontend Components
- [ ] `app/components/Admin/UserWallet.tsx` - نمایش موجودی کاربر
- [ ] `app/components/Admin/ChargeWalletModal.tsx` - Modal شارژ موجودی
- [ ] `app/components/Admin/UserTransactions.tsx` - لیست تراکنش‌ها
- [ ] `app/components/Admin/UserDetailsModal.tsx` - جزئیات کاربر

### فایل‌های بهبود یافته
- [ ] `app/admin/page.tsx` - بهبود پنل ادمین
- [ ] `app/api/admin/users/route.ts` - اضافه کردن موجودی به response

---

## ⚠️ نکات مهم

1. **بدون تغییر دیتابیس**: تمام قابلیت‌ها با استفاده از فیلدهای موجود (`referenceId`, `metadata` در جدول `transactions`) پیاده‌سازی می‌شوند.

2. **استایل مشابه**: تمام کامپوننت‌های جدید باید با استایل و ساختار کامپوننت‌های موجود هماهنگ باشند.

3. **RTL Support**: تمام UI باید از راست به چپ (RTL) پشتیبانی کند.

4. **Error Handling**: تمام عملیات باید error handling مناسب داشته باشند.

5. **Security**: تمام API ها باید بررسی دسترسی ادمین داشته باشند.

6. **Logging**: تمام عملیات مهم باید logging داشته باشند.

7. **Node.js Deployment**: این پروژه برای Node.js deployment است (نه Docker).

---

## 🎯 اولویت‌بندی

### فوری (Critical)
1. API شارژ دستی موجودی
2. کامپوننت Modal شارژ موجودی
3. بهبود تب کاربران در پنل ادمین
4. API مشاهده موجودی کاربر

### مهم (High Priority)
5. کامپوننت مشاهده موجودی کاربر
6. کامپوننت لیست تراکنش‌ها
7. بهبود Validation و Security

### متوسط (Medium Priority)
8. کامپوننت جزئیات کاربر
9. بهبود UI/UX
10. Logging و Monitoring

### کم‌اهمیت (Low Priority)
11. Documentation
12. Real-time updates
13. Advanced features

---

**تاریخ ایجاد:** 2024-11-21  
**وضعیت:** در انتظار پیاده‌سازی  
**اولویت:** فوری

